// src/constants/routes.js
export const ROUTES = {
  HOME: "/",
  TONIGHT: "/tonight",
  EVENT_DETAIL: "/events/:eventId",
  CONFIRM_BOOKING: "/events/:eventId/book",
  PAYMENT: "/bookings/:bookingId/pay",
  VENDORS: "/vendors",
  VENDOR_PROFILE: "/vendors/:vendorId",
  MARKETPLACE: "/marketplace",
  ORGANIZER_SUBMIT: "/organizer/submit",
  ORGANIZER_REGISTER: "/organizer/register",
  ORGANIZER_KYC: "/organizer/kyc",
  MY_EVENTS: "/organizer/events",
  EVENT_STAFF: "/organizer/events/:eventId/staff",
  EVENT_EDIT: "/organizer/events/:eventId/edit",
  EVENT_CHECKIN: "/organizer/events/:eventId/checkin",
  ADMIN: "/admin",
  PROFILE: "/profile",
  PROFILE_EDIT: "/profile/edit",
  LOGIN: "/login",
  SIGNUP: "/signup",
  MAP: "/map",
  FORGOT: "/forgot-password",
  ONBOARDING: "/onboarding",
  VENDOR_REGISTER: "/vendor/register",
  VENDOR_LEADS: "/vendor/leads",
  VENDOR_BOOKINGS: "/vendor/bookings",
  VENDOR_PAYOUTS: "/vendor/payouts",
  VENDOR_DASHBOARD: "/vendor/dashboard",
  VENDOR_PACKAGES: "/vendor/:vendorId/services/:serviceId/packages",
  VENDOR_ADDONS: "/vendor/:vendorId/packages/:packageId/addons",
  REQUEST_MATCHES: "/requests/:reference/matches",
  MY_REQUESTS: "/requests",
  NOT_FOUND: "*",
};

// Helper to build dynamic paths
export const buildRoute = {
  eventDetail: (id) => `/events/${id}`,
  vendorProfile: (id) => `/vendors/${id}`,
  confirmBooking: (id) => `/events/${id}/book`,
  payment: (bookingId) => `/bookings/${bookingId}/pay`,
  eventStaff: (id) => `/organizer/events/${id}/staff`,
  eventEdit: (id) => `/organizer/events/${id}/edit`,
  eventCheckin: (id) => `/organizer/events/${id}/checkin`,
  vendorPackages: (vendorId, serviceId) =>
    `/vendor/${vendorId}/services/${serviceId}/packages`,
  vendorAddons: (vendorId, packageId) =>
    `/vendor/${vendorId}/packages/${packageId}/addons`,

  requestMatches: (reference) => `/requests/${reference}/matches`,
};
